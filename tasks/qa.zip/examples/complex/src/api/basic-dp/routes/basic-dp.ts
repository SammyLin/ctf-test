/**
 * basic-dp router
 */

import { factories } from '@strapi/strapi';

export default factories.createCoreRouter('api::basic-dp.basic-dp');

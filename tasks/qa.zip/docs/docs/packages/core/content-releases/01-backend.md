---
title: Backend Design
description: Content Releases backend
tags:
  - tech-design
  - backend
review_notes:
  - 'Says scheduling needs the `contentReleasesScheduling` future flag. The name has no reference in the package code on develop; scheduling may be always on.'
status: needs-review
---

All backend code can be found in:

```
 packages/core/content-releases/server
```

## Content-types

The content-releases plugin creates two hidden content-types.

### Release

The `Release` content type stores all the information about a release and its associated Release Actions. It is saved in the database as `strapi_releases`. The schema can be found in:

```
packages/core/content-releases/server/src/content-types/release/schema.ts
```

`releasedAt` is when the release ran, or when the overdue sweep froze it without running (see [Overdue releases](#overdue-releases)). A release with `releasedAt` set is frozen: it can't be edited, deleted, published again or gain, lose or change entries, and it no longer counts as pending. Deleting is only for a planned release: a "Failed" one stays too (`DELETE` is refused with `Release already published`). On a "Failed" release nothing went live, except on one that failed before the upgrade, which may have released some entries.

### Release Action

Th `Release Action` content type is associated with any entry from any content-type that has draft and publish enabled. It is responsible for storing the action to perform for an associated entry. It is saved in the database as `strapi_release_actions`. In v4, we used built-in polymorphic relations, but for v5, we stored `contentType`, `locale`, and `entryDocumentId` in the Release Action schema to create a "manual" relationship between actions and entries. This approach allows us to link a release action to a document ID instead of a specific entry ID, as the entry ID may change over time and is not reliable.

Only an action of a localized content type has a `locale`. The Content Manager sends the locale of its URL whatever the content type, so adding an action drops it for a content type that isn't localized, before the "already in the release" check: such an entry has one version, whatever the locale. Listing a release's actions (`groupActions`) also shows no locale for those content types, for actions stored before.

The schema can be found in:

```
packages/core/content-releases/server/src/content-types/release-action/schema.ts
```

## Routes

Release and Release Action routes are only accessible on the Admin API.

### Release

Release routes can be found in:

```
packages/core/content-releases/server/src/routes/release.ts
```

**Get all releases**:

- method: `GET`
- endpoint: `/content-releases/`
- params:
  ```ts
  {
    page: number;
    pageSize: number;
    // Any field of the release, e.g. filters[status][$in][0]=failed or
    // filters[scheduledAt][$null]=true
    filters?: Record<string, unknown>;
    sort?: string | string[]; // e.g. 'updatedAt:desc'
  }
  ```
- response `meta`: `pagination`, `pendingReleasesCount` (releases without `releasedAt`) and `statusCounts` (how many releases have each status, whatever the filters)
- a sort starting with `scheduledAt` lists the unscheduled releases first in either direction. Each database places nulls its own way, so `findPage` counts the unscheduled and scheduled releases matching the filters, then fills the page from the unscheduled ones first and the scheduled ones after. Ties, and the unscheduled releases, go most recently updated first, then by `id`.

**Get all releases with/without an entry**:

- method: `GET`
- endpoint: `/content-releases/getByDocumentAttached`
- params:
  ```ts
  {
    contentType: string;
    locale?: string;
    entryDocumentId?: string;
    hasEntryAttached?: boolean;
  }
  ```

**Get a single release**

- method: `GET`
- endpoint: `/content-releases/:id`

**Create a release**:

- method: `POST`
- endpoint: `/content-releases/`
- body:
  ```ts
  {
    name: string;
    scheduledAt?: string | null; // ISO date
    timezone?: string | null; // required when scheduledAt is set
    releaseCondition?: 'all_or_nothing' | 'allow_partial'; // all_or_nothing if omitted
  }
  ```

**Update a release**:

- method: `PUT`
- endpoint: `/content-releases/:id`
- body:
  ```ts
  {
    name: string;
    scheduledAt?: string | null; // null or omitted unschedules the release
    timezone?: string | null; // required when scheduledAt is set; null or omitted clears it
    releaseCondition?: 'all_or_nothing' | 'allow_partial';
  }
  ```

**Delete a release**:

- method: `DELETE`
- endpoint: `/content-releases/:id`
- only a planned release (no `releasedAt`) can be deleted; one that ran, "Failed" included, is refused with a 400: `Release already published`

**Publish a release**:

- method: `POST`
- endpoint: `/content-releases/:id/publish`

**Create a release from skipped entries**:

- method: `POST`
- endpoint: `/content-releases/:id/create-from-skipped-entries`
- permissions: `plugin::content-releases.create` and `plugin::content-releases.create-action`
- response: the new release, with `actions.meta.count`
- body:
  ```ts
  {
    name: string;
    scheduledAt?: string | null; // ISO date
    timezone?: string | null; // required when scheduledAt is set
    releaseCondition?: 'all_or_nothing' | 'allow_partial';
    actionIds?: number[]; // skipped entries to carry over; all of them if omitted, an empty array is a 400
  }
  ```

### Release Action

**Create a release action**

- method: `POST`
- endpoint: `/content-releases/:releaseId/actions`
- body:

  ```ts
  {
    type: 'publish' | 'unpublish',
    contentType: string;
    locale?: string;
    entryDocumentId?: string;
  }
  ```

**Get release actions from a release**

- method: `GET`
- endpoint: `/content-releases/:releaseId/actions`
- params:
  ```ts
  {
    page: number;
    pageSize: number;
    groupBy?: 'contentType' | 'action' | 'locale';
    // ready / notReady: whether the entry is publishable (every unpublish is). On a release that
    // ran, that's what the run found.
    // released / skipped: what the run did with the entry. Nothing matches on a planned release.
    // blocking: skipped for a reason of its own (skipped_invalid, skipped_not_approved,
    // skipped_error), not held or missed: in an `all_or_nothing` run, what held back the rest.
    filter?: 'ready' | 'notReady' | 'released' | 'skipped' | 'blocking';
    // Any field of the release action, narrowing the result further, e.g.
    // filters[outcome][$in][0]=skipped_invalid
    filters?: Record<string, unknown>;
  }
  ```
- each action has its `entry`, or `null` when the entry or its content type was deleted after the release ran

**Update a release action**

- method: `PUT`
- endpoint: `/content-releases/:releaseId/actions/:actionId`
- body:
  ```ts
  {
    type: 'publish' | 'unpublish';
  }
  ```

**Delete a release action**

- method: `DELETE`
- endpoint: `/content-releases/:releaseId/actions/:actionId`

## Controllers

### Release

Handles requests to interact with the Release content type

```
packages/core/content-releases/server/src/controllers/release.ts
```

### Release Action

Handles requests to interact with the Release Action content type

## Services

### Release

Interacts with the database for Release CRUD operations

```
packages/core/content-releases/server/src/services/release.ts
```

### Release Actions

Interacts with the database for Release Actions CRUD operations

```
packages/core/content-releases/server/src/services/release-action.ts
```

### Release Validation

Exposes validation functions to run before performing operations on a Release

```
packages/core/content-releases/server/src/services/validation.ts
```

### Scheduling

Exposes methods to schedule release date for releases.

```
packages/core/content-releases/server/src/services/scheduling.ts
```

#### Overdue releases

`syncFromDatabase` arms future dates, and runs right away a release whose date passed by less than the grace period (the server was restarting when it was due): it uses the scheduled run's path (`publish` with `trigger: 'scheduled'`, under the release lock), so with several instances booting together one runs it and the others find it already published. A release that comes due while the sync is still arming jobs runs right away too: cron never fires a job for a date already past, so the sync cancels that job. A release whose scheduled run didn't happen otherwise would stay in Pending with a past date. `freezeOverdueReleases` runs at bootstrap, before `syncFromDatabase` and with the same `now`, then every minute, and freezes these releases (`releasedAt` set) without running anything:

- a release whose `scheduledAt` is older than the grace period (`OVERDUE_GRACE_PERIOD_MS`, 5 minutes): the server was down, or the run was rolled back by a database error. `failureReason` is `missed_schedule`. It sends the `releases.publish` webhook (`isPublished: false`, an error named `MissedSchedule`) and a `release.trigger` audit failure attributed to the scheduler. A release with no entries missed nothing: it ends "Done" instead (totals all 0, `failureReason` `null`), with the success webhook and audit event its scheduled run would have sent.
- a release that failed before the upgrade: before failed runs were frozen, they left `status: failed` without `releasedAt`. It's frozen whatever its schedule, its job never armed. `failureReason` is `failed_before_upgrade`, and nothing is sent: it reported its failure then. It stays "Failed" even with no entries.

Until the grace period has passed, an overdue release stays planned and can be published by hand: publishing late beats failing. The grace period also keeps the sweep from freezing a release its scheduled run is about to release. A manual publish doesn't check the schedule, on purpose.

Every entry gets the outcome `skipped_missed` and keeps the validity last checked (nothing is checked at freeze time). The totals are 0 published, 0 unpublished, every entry skipped, so "Create release from skipped entries" carries over every entry of a release that missed its schedule. For `failed_before_upgrade` they don't say what went out: the old run stopped at its first error and kept the entries released before it, and nothing recorded which. Read them as unknown, not as skipped: the API returns `skipped_missed` and these totals, with only `failureReason` telling the two apart. "Create release from skipped entries" refuses such a release (the admin hides the button), so it doesn't publish entries again; otherwise it shows like one that missed its schedule.

Each release is frozen in its own transaction, under a run's row lock, and checked again under it: a run in progress, or a reschedule to a later date, wins. It reads no entry, so it can't deadlock with a run. It throws inside another transaction, which would hold every lock until that one ends. A sweep that starts during another joins it; on a cluster, the lock lets one node freeze and report each release. A release that fails to freeze is left for the next sweep. On MySQL, a run still going 5 minutes after its date can make the sweep's lock wait time out (`innodb_lock_wait_timeout`): that's logged every minute until the run commits. `failureReason` is `null` on every release that ran, and on an empty release that missed its schedule, which the sweep froze as done; an empty `failed_before_upgrade` release keeps its `failureReason` and is frozen as failed.

### Release status update triggers:

Each release has a `releaseCondition`: `all_or_nothing` (the default, also given to releases created before the field existed) or `allow_partial`.

A publish entry is publishable when its draft passes publish validation and, if its review workflow has a stage required to publish, it is at that stage. Unpublish entries are always publishable. Each release action stores whether its entry was publishable when last checked (`isEntryValid`) and, if not, why (`reason`, the shape a run records). The check reads the deep-populated draft, as a run does, so the stored reason matches what the run will decide. A draft that can't be read is stored as not publishable, with only the error's name, and its message if it's an `ApplicationError` (meant for the client; another error's message can carry row contents). Only planned releases are rewritten: a release that ran keeps what its run saw.

The validity is written when an entry is added or changes type, when a manual publish is rejected by the check, and through `revalidatePlannedActions` when:

- the entry is edited or its draft discarded;
- a review workflow is created, updated or deleted;
- a content type's attributes change, at startup;
- at startup, for planned actions stored as not publishable before reasons existed (`addReasonsToInvalidActions`).

`revalidatePlannedActions` reads the planned actions (`PLANNED_ACTION_WHERE`) and their drafts before taking any lock, each draft once however many releases the entry is in. Then it changes one release at a time, each in its own transaction under the release lock, and recalculates its status. A release that ran in between is left alone; one whose writes fail is logged without stopping the others. Each draft's `updatedAt` is read before the check and again under the lock: a draft saved in between is checked again under the lock, so a revalidation that started before a save never overwrites the result of the save's own, newer revalidation. Entry and workflow changes start it after their commit, without waiting (`runAfterCommit`), so their writes never wait on a release lock a run holds.

The releases list and the single release response return `actions.meta.notReadyCount` for planned releases: the publish entries that aren't publishable now. With `actions.meta.count` and the release condition, it gives the status the other condition would have, so no per-condition status is stored.

- **Empty**: the release has no entries.
- **Blocked**: publishing now would release nothing. With `all_or_nothing`, at least one entry is not publishable. With `allow_partial`, no entry is publishable.
- **Ready**: otherwise. An `allow_partial` release with some entries that aren't publishable is ready: they are skipped when it runs.

A release is planned (Empty, Ready, Blocked) until it runs. After it runs, it is frozen with one of these statuses, which nothing changes afterwards:

- **Done**: every entry was published or unpublished. A release with no entries ends done when it runs or misses its schedule; an empty release that failed before the upgrade ends failed.
- **Partial**: some entries were released and some were not.
- **Failed**: no entry was released.

Considering that retrieving the status of all entries in a release is a heavy operation, we don't fetch it every time a user wants to access a release. Instead, we store the status in a field within the Release Content Type, and we only update it when an action that changes the status is triggered. These actions include:

#### Creating a release:

When creating a release, its status is automatically set to "Empty" as there are no entries initially.

#### Creating a release from skipped entries:

A release that ran can't change, so its skipped entries are released again through a new release: `POST /content-releases/:id/create-from-skipped-entries`.

- An entry is skipped when its outcome is neither `published` nor `unpublished`.
- Only a `partial` or `failed` release that ran is accepted. A release that hasn't run is rejected with `Release not published yet`, a `done` one with `Release has no skipped entries`, one that failed before the upgrade with `Release failed before the upgrade, so its skipped entries are unknown` (all 400). An unknown `:id` is a 404.
- The new release's fields are validated like any new release. `actionIds` restricts the entries to those actions; it must hold at least one id (an empty array is a 400, omit it to carry over every skipped entry), and an id that isn't a skipped entry of the release is a 400.
- Each entry keeps its type and locale, in the order it was added. Its validity is read from the entry as it is now, and the new release's status follows from it.
- Entries deleted since the run (in their locale, for a localized content type), or whose content type was deleted or lost Draft and Publish, are left out. If nothing is left, the request is rejected with a 400: `Release has no skipped entries`, or `The requested entries can no longer be released` when `actionIds` was given.
- The release, its entries and its status are written in one transaction. The source release isn't changed.

#### Adding an entry to a release:

Upon adding an entry to a release, its status is recalculated to either "Ready" or "Blocked" from the validity of its entries and its release condition.

The recalculations below only apply to a planned release. `updateReleaseStatus` also leaves alone a `failed` release without `releasedAt`, which failed before the upgrade and is left for the overdue sweep. It reads the release under its row lock, so its counts are those of the last committed change and it can't overwrite a newer status. The stored validity has no such guarantee: two overlapping re-checks of an entry can leave the older draft's validity until the next one.

Changing a release's entries through the API writes the change and the recalculated status in one transaction, under the release lock: if the recalculation fails, the change is rolled back, and a release that ran is refused (`Release already published`). Editing or deleting the release takes the same lock, so one frozen while the request was in flight is refused. Editing, discarding or deleting the entry recalculates in the background (see "Listening to events on entries").

#### Removing an entry from a release:

After removing an entry from a release, the status is recalculated to determine if the release is now "Ready", "Blocked", or "Empty".

#### Updating a release:

Whenever a release is updated, its status is recalculated, so switching the release condition switches between "Ready" and "Blocked". The recalculation is awaited, so a read right after the update sees the new status.

#### Publishing a release:

A publish is either manual (the publish button or the API) or scheduled (the scheduler, at the release date). Under the release row lock, the run first reads every publish entry's current draft and checks whether it is publishable, before writing anything. A check that throws, whatever the error (e.g. its draft can't be read), isn't an entry validation result: the entry is recorded as `skipped_error` with `isEntryValid: false`, and isn't publishable. With `api.documents.strictRelations`, the check validates the draft as publish does: publish connects each relation to its target's published version and drops the targets without one, so a required relation counts only its targets that have a published version or that an earlier entry of the same run publishes (and not one an earlier entry unpublishes). It doesn't know whether that earlier entry will go out: if it doesn't, the entry fails when written, as below. A planned release's stored validity checks the draft as is, since which targets a run releases first is only known in the run. Entries are then handled one at a time: content types in relation dependency order, publishes before unpublishes, each in the order they were added. They share the lock transaction, and are written in savepoints (`strapi.db.savepoint`), so a failure rolls back exactly what it should.

- `allow_partial`: entries that aren't publishable are skipped without being written. Each other entry is published or unpublished in its own savepoint: if that throws, only that entry is rolled back and skipped, and the run moves on. The check can pass an entry that still fails when written, for example when an earlier entry of the same run takes its unique value: since a publish removes the entry's published version before it validates the new one, the savepoint is what keeps that version online.
- `all_or_nothing`: if any entry isn't publishable, no entry is written. Otherwise every entry is published or unpublished in one savepoint, and the first error rolls them all back.

The run decides from this check, not from the stored status: a release that reads "Blocked" only because a background revalidation hasn't caught up with a fixed entry yet is published. When the check finds that a run would release nothing (`all_or_nothing`: any entry not publishable; `allow_partial`: no entry publishable; never for a release with no entries):

- A manual publish is rejected (400) with the first not-publishable entry's own error, in run order. When only checks that threw block it, the error is `An entry couldn't be checked (<error name>)`, never the thrown message. Nothing is published, each check that ran is stored on the release actions (`isEntryValid`), and the status is recalculated, so the release stays planned and reads "Blocked" even if the stored values had gone out of date. A check that threw (e.g. a transient read error) found nothing about its entry: it isn't stored, the entry keeps the validity stored before. No webhook or audit event is sent.
- A scheduled run fails: the release is frozen as "Failed". For `all_or_nothing`, it records the first not-publishable entry's own error, or else the first thrown check's error; for `allow_partial`, `No entries were published`.

Database caveats:

- A conflict with another transaction isn't the entry's own failure, so it isn't recorded as `skipped_error`: a MySQL deadlock (`ER_LOCK_DEADLOCK`, InnoDB rolls back the whole transaction, not the savepoint) or lock wait timeout (`ER_LOCK_WAIT_TIMEOUT`), a Postgres deadlock (`40P01`) or serialization failure (`40001`). Nor is a savepoint the database couldn't release or roll back to (`SavepointError`, see Database transactions), e.g. after a lock wait timeout with `innodb_rollback_on_timeout` rolled the whole transaction back. Under either mode, during the check or the writes, it rolls the whole run back, nothing is recorded, the release stays planned, and the request fails with a 500. A lock wait timeout is treated as a conflict whatever `innodb_rollback_on_timeout` says: with it off, InnoDB only rolls back the statement, but the entry still didn't fail on its own.
- An unexpected error that stops a manual `all_or_nothing` run is recorded as "Failed", and the request fails with a 400 that carries the frozen release in `error.details.release`: a validation error keeps its message and details; any error that isn't an `ApplicationError` becomes `An entry couldn't be released (<error name>)`, never the thrown message, which is logged instead. Another `ApplicationError` is sent as is (its own status, no release). A run that rolls back (a conflict, a failed write of what it did) still fails with a 500.

How a run ends:

- Every entry released, or no entries at all: "Done", with `releasedAt` set.
- Some entries released and some not (an `allow_partial` run that skipped entries): "Partial", with `releasedAt` set.
- No entry released (an `allow_partial` run whose entries all failed, or an `all_or_nothing` run stopped by an error): "Failed", with `releasedAt` set, and the request fails. A validation error (400) then carries the frozen release in `error.details.release`, which a refused publish never has. The release leaves Pending and can't be published again: its entries go out in a new release.

A run either records its outcome or doesn't happen. Only the failures the run decides are recorded as "Failed" (a scheduled run stopped by the check, an `all_or_nothing` run stopped by an entry error, an `allow_partial` run where every entry failed). Any other error (reading the entries, writing the result, the writes of a rejected manual publish) rolls the whole transaction back, the entries it released included: the request fails, the release stays as it was, and no webhook or audit event is sent. A scheduled release whose run rolled back is frozen by the overdue sweep (see Scheduling); a manual one can be published again.

Each entry of the run records what happened to it on its release action, returned by `GET /content-releases/:releaseId/actions`:

| `outcome`              | When                                                                                                                                                                                                                                                                                                                                 | `reason`                                                                                                                                                                                                                      |
| ---------------------- | ------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------ | ----------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------------- |
| `published`            | the entry was published                                                                                                                                                                                                                                                                                                              | `null`                                                                                                                                                                                                                        |
| `unpublished`          | the entry's published version was removed, or the entry was already unpublished (its draft is there, with nothing to remove)                                                                                                                                                                                                         | `null`                                                                                                                                                                                                                        |
| `skipped_invalid`      | the draft failed publish validation, whether or not it was also at the wrong stage, or publishing it raised a validation error (e.g. a unique clash with another entry of the run), or the entry is gone: a publish finds no draft, an unpublish finds neither a published version nor a draft (an `all_or_nothing` run fails on it) | `validation.errors`: field `path` and `message`, without the error's `value`; a type-mismatch message loses the value it ends with; empty for an entry that's gone                                                            |
| `skipped_not_approved` | the entry wasn't at the stage required to publish, at the check or when review-workflows refused its publish                                                                                                                                                                                                                         | `stage`: the entry's stage and the required one, read again after a refused publish (if that read fails, `error` with the refusal)                                                                                            |
| `skipped_error`        | publishing or unpublishing the entry threw an error other than a validation error, or checking it threw any error                                                                                                                                                                                                                    | `error.name`, and `error.code` for a database driver's error (e.g. `23505`: node-postgres names its errors `error`); `error.message` too for an `ApplicationError`, never another error's message (it can carry row contents) |
| `skipped_held`         | the entry was publishable, but an `all_or_nothing` run released nothing (at the check or after an error)                                                                                                                                                                                                                             | `null`                                                                                                                                                                                                                        |
| `skipped_missed`       | the release froze without running: its scheduled run never happened, or it failed before the upgrade (frozen by the overdue sweep, see Scheduling)                                                                                                                                                                                   | unchanged: the validity last stored                                                                                                                                                                                           |

An entry that fails both checks keeps both in its `reason`. The outcomes are written in the lock transaction with the release's status, with the validity the run found: `isEntryValid` is `false` for `skipped_invalid` and `skipped_not_approved`, and `true` for every other outcome except a `skipped_error` entry whose check threw, so it never contradicts the outcome. A release runs once: its outcomes are never rewritten afterwards, a `failed` release included. A run that records nothing leaves `outcome` empty: a manual publish rejected by the check (it didn't run), and a run the database rolls back.

The run also stores its totals on the release, with its status: `totalPublishedEntries` and `totalUnpublishedEntries` count the entries recorded as `published` and `unpublished`, and `totalSkippedEntries` every other entry of the run, whatever the reason (each entry keeps its own `outcome` and `reason`). The three always add up to the release's entries when it ran: a "Failed" release has 0 published and every entry skipped. `GET /content-releases/:id` and `GET /content-releases` return them on each release, and `POST /content-releases/:id/publish` returns them in its `meta` too, with `totalEntries` their sum. They stay `null` while the release is planned, including after a manual publish rejected by the check.

The status written, the `releases.publish` webhook and the `release.trigger` audit event always agree. The webhook's `release` is the release as the run left it, with its totals, also when it failed:

| Status  | Webhook `isPublished` | Audit `outcome` | Audit `details`                         |
| ------- | --------------------- | --------------- | --------------------------------------- |
| Done    | `true`                | `success`       | `published`, `unpublished`, `failed: 0` |
| Partial | `true`                | `partial`       | `published`, `unpublished`, `failed`    |
| Failed  | `false`               | `failure`       | `reason`: the error's name              |

The audit counts are the release's totals, `failed` being `totalSkippedEntries`: the entries the run left out, not publishable, or their publish or unpublish threw. The webhook and the audit event are sent once the outcome is committed. Entry errors are rolled back with their savepoint, so on Postgres they don't abort the transaction; any other error rolls back the whole run, as above.

#### Listening to events on entries:

When an entry is updated, its draft is discarded or it is deleted, the status of all releases containing that entry is recalculated to reflect any changes in validity. Only releases that haven't run are affected: an update or a discarded draft rewrites `isEntryValid` and `reason` (a discarded draft is replaced by the published version, for each locale it was discarded in) and a deletion removes the entry's actions only there. A release that ran keeps the actions of deleted entries, with what the run recorded; `GET /content-releases/:releaseId/actions` returns them with a `null` `entry` and `status`.

This work isn't awaited by the entry's request (`runAfterCommit`) and runs outside its transaction, so the request responds before the releases' `isEntryValid`, `reason` and status change: a client that shows them right after a save must re-read them until they do. It starts once that transaction commits (right away without one). It reads the committed entry, can't undo the request's writes, and doesn't run for a change that was rolled back. Each affected release is then changed in a transaction of its own, under its lock. Failures are logged.

On delete, `createDeleteActionsOnDelete` removes the actions of the locales the delete removed, resolved the way the Document Service resolves the `locale` param: every action of the document for a non-localized content type (their locale is stored as `null`) or for `locale: '*'`, the given locale or locales otherwise, and the default locale when none is given.

## Migrations

These run on every content type sync. The revalidation passes aren't awaited by startup and log their failures.

- Before the sync: `disableContentTypeLocalized` (the actions of a content type that is no longer localized lose their locale).
- After the sync:
  - `deleteActionsOnDeleteContentType` and `deleteActionsOnDisableDraftAndPublish`: the content type's actions leave every planned release. Releases that ran keep them; for a deleted content type, they're listed with a `null` `entry` and the uid as display name. They run after the sync because they recalculate statuses, which reads the current schema.
  - `enableContentTypeLocalized`: the actions of a newly localized content type get the default locale.
  - `revalidateChangedContentTypes`: the planned actions of content types whose attributes changed are revalidated.
  - `migrateIsValidAndStatusReleases`: releases from before statuses existed get one.
  - `addReasonsToInvalidActions`: see above.
  - `migrateReleaseConditionReleases`: releases from before the condition existed get `all_or_nothing`.
  - `addOutcomesToReleasedReleases`: a release that ran before outcomes existed released every entry (a failed run left it planned), so each action gets `published` or `unpublished` and the release its totals and the status `done` (an entry change used to recalculate a released release's status as if it were planned). A release a since-removed migration froze as `failed_before_upgrade`, without totals, gets every entry `skipped_missed` and all-skipped totals, as the sweep writes.

Releases that failed before the upgrade are frozen by the overdue sweep at bootstrap (see Scheduling).

`addReasonsToInvalidActions` finds again, at the next start, the actions of a release whose revalidation failed. `revalidateChangedContentTypes` doesn't: once the sync has stored the new schema, the attributes no longer differ, so a failed release keeps its stored validity until its entries change.

## Subscribing to Lifecycles Events

When entries are deleted outside the Document Service (`afterDeleteMany`, e.g. when a locale is deleted), their actions are deleted in releases that haven't run and those releases' status is recalculated, after the deletion commits, as in "Listening to events on entries".

---
title: useAdminRoles
description: API reference for the useAdminRoles hook
tags:
  - hooks
---

An abstraction around `react-query`'s `useQuery` hook. It can be used to fetch one or more admin role.

## Usage

The hooks can receive two optional parameters:

1. query params: an object containing the query params to be sent to the API. They are going to be
   stringified by `qs`. All params are equal except `id`, which is used to fetch a single users, if
   it is passed.
2. options: an object containing the options to be passed to `useQuery`.

It returns an object containing some of the react-query attributes.

## Typescript

```ts
import { UseQueryOptions } from 'react-query'

type Role = object;

useAdminRoles(queryParams: object, reactQueryOptions: UseQueryOptions): {
    roles: Role[],
    isLoading: boolean;
    error: object;
    isError: boolean;
    refetch: () => Promise<void>;
};
```

### Fetch all roles

```jsx
import { useAdminRoles } from 'path/to/hooks';

const MyComponent = ({ onMoveItem }) => {
  const { roles, isLoading, refetch } = useAdminRoles();

  // ...
};
```

### Fetch one role

```jsx
import { Box } from '@strapi/design-system';

import { useAdminRoles } from 'path/to/hooks';

const MyComponent = ({ onMoveItem }) => {
  const {
    users: [user],
    isLoading,
    refetch,
  } = useAdminRoles({ id: 1 });

  // ...
};
```

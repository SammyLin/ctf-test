'use strict';

jest.mock('@actions/github');
jest.mock('@actions/core');

const github = require('@actions/github');
const core = require('@actions/core');
const action = require('../index');

beforeEach(() => {
  jest.clearAllMocks();
});

test.each(action.BLOCKING_LABELS)('Test blocking labels %s', async (label) => {
  github.context = {
    payload: {
      pull_request: {
        labels: [{ name: label }],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).toHaveBeenCalled();
  expect(setFailed.mock.calls[0][0]).toContain(`The PR has been labelled with a blocking label`);

  setFailed.mockRestore();
});

test('Test missing QA label blocks PR', async () => {
  github.context = {
    payload: {
      pull_request: {
        base: {
          ref: 'main',
        },
        author_association: 'MEMBER',
        labels: [{ name: 'pr: enhancement' }, { name: 'source: core' }],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).toHaveBeenCalled();
  expect(setFailed.mock.calls[0][0]).toBe(
    `The PR must have one of the following QA labels: qa-done, qa-skipped.`
  );

  setFailed.mockRestore();
});

test('Test needs-qa alone does not satisfy the QA gate', async () => {
  github.context = {
    payload: {
      pull_request: {
        base: {
          ref: 'main',
        },
        author_association: 'MEMBER',
        labels: [{ name: 'needs-qa' }, { name: 'pr: enhancement' }, { name: 'source: core' }],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).toHaveBeenCalled();
  expect(setFailed.mock.calls[0][0]).toBe(
    `The PR must have one of the following QA labels: qa-done, qa-skipped.`
  );

  setFailed.mockRestore();
});

test.each(action.QA_COMPLETION_LABELS)('Test %s label allows PR', async (label) => {
  github.context = {
    payload: {
      pull_request: {
        base: {
          ref: 'main',
        },
        author_association: 'MEMBER',
        labels: [{ name: label }, { name: 'pr: enhancement' }, { name: 'source: core' }],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).not.toHaveBeenCalled();

  setFailed.mockRestore();
});

test('Test missing source label', async () => {
  github.context = {
    payload: {
      pull_request: {
        labels: [{ name: 'qa-done' }, { name: 'pr: enhancement' }],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).toHaveBeenCalled();
  expect(setFailed.mock.calls[0][0]).toBe(`The PR must have one and only one 'source:' label.`);

  setFailed.mockRestore();
});

test('Test too many source label', async () => {
  github.context = {
    payload: {
      pull_request: {
        labels: [
          { name: 'qa-done' },
          { name: 'source: a' },
          { name: 'source: b' },
          { name: 'pr: enhancement' },
        ],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).toHaveBeenCalled();
  expect(setFailed.mock.calls[0][0]).toBe(`The PR must have one and only one 'source:' label.`);

  setFailed.mockRestore();
});

test('Test missing pr label', async () => {
  github.context = {
    payload: {
      pull_request: {
        labels: [{ name: 'qa-done' }, { name: 'source: core' }],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).toHaveBeenCalled();
  expect(setFailed.mock.calls[0][0]).toBe(`The PR must have one and only one 'pr:' label.`);

  setFailed.mockRestore();
});

test('Test too many pr label', async () => {
  github.context = {
    payload: {
      pull_request: {
        labels: [
          { name: 'qa-done' },
          { name: 'pr: a' },
          { name: 'pr: b' },
          { name: 'source: core' },
        ],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).toHaveBeenCalled();
  expect(setFailed.mock.calls[0][0]).toBe(`The PR must have one and only one 'pr:' label.`);

  setFailed.mockRestore();
});

test.each(['NONE', 'CONTRIBUTOR', 'FIRST_TIME_CONTRIBUTOR', 'COLLABORATOR'])(
  'Test community PR targeting main is blocked for %s author',
  async (authorAssociation) => {
    github.context = {
      payload: {
        pull_request: {
          base: {
            ref: 'main',
          },
          author_association: authorAssociation,
          labels: [{ name: 'qa-done' }, { name: 'pr: enhancement' }, { name: 'source: core' }],
        },
      },
    };

    const setFailed = jest.spyOn(core, 'setFailed');
    const info = jest.spyOn(core, 'info');

    await action();

    expect(info).toHaveBeenCalledWith(`PR author_association: ${authorAssociation}`);
    expect(setFailed).toHaveBeenCalled();
    expect(setFailed.mock.calls[0][0]).toBe(
      'Community PRs must target `develop`, not `main`. Please edit the PR and change the base branch to `develop`.'
    );

    setFailed.mockRestore();
    info.mockRestore();
  }
);

test.each(action.STRAPI_ENGINEER_ASSOCIATIONS)(
  'Test Strapi engineer may target main (%s author)',
  async (authorAssociation) => {
    github.context = {
      payload: {
        pull_request: {
          base: {
            ref: 'main',
          },
          author_association: authorAssociation,
          labels: [{ name: 'qa-done' }, { name: 'pr: enhancement' }, { name: 'source: core' }],
        },
      },
    };

    const setFailed = jest.spyOn(core, 'setFailed');
    const info = jest.spyOn(core, 'info');

    await action();

    expect(info).toHaveBeenCalledWith(`PR author_association: ${authorAssociation}`);
    expect(setFailed).not.toHaveBeenCalled();

    setFailed.mockRestore();
    info.mockRestore();
  }
);

test('Test community PR may target a feature branch (stacked PR)', async () => {
  github.context = {
    payload: {
      pull_request: {
        base: {
          ref: 'feat/part-one',
        },
        author_association: 'FIRST_TIME_CONTRIBUTOR',
        labels: [{ name: 'qa-done' }, { name: 'pr: enhancement' }, { name: 'source: core' }],
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).not.toHaveBeenCalled();

  setFailed.mockRestore();
});

test('Test develop PR without a milestone is allowed', async () => {
  github.context = {
    payload: {
      pull_request: {
        base: {
          ref: 'develop',
        },
        labels: [{ name: 'qa-done' }, { name: 'pr: enhancement' }, { name: 'source: core' }],
        milestone: null,
      },
    },
  };

  const setFailed = jest.spyOn(core, 'setFailed');

  await action();

  expect(setFailed).not.toHaveBeenCalled();

  setFailed.mockRestore();
});
